Thank you for downloading ACC Live Leaderboard Manager v1.0

Check out my other apps for ACC!

ACCR-Sync v1.0 ( Can be integrate into ACC Leaderboard Manager v1.0)
--------------------------------------------------------------------
Syncs Dedicated Server Hotlap Results to an online hotlap leaderboard where players can check their own fastest laps and their friends of course on your server. :)

https://www.accracehost.com/accrsync.html
https://www.overtake.gg/downloads/accr-sync-live-hotlap-leaderboard.86363/


ACC Race Host v1.03
-------------------
ACC Dedicated server application with webinterface administration, track rotation, ban list and driver entry management.

https://www.accracehost.com
https://www.overtake.gg/downloads/acc-race-host.86243/


For Professonal Grade Liveries both public (free) and commissioned.
-------------------------------------------------------------------
https://www.newbfixer.com/
https://www.overtake.gg/downloads/authors/newbfixer.2818380/
